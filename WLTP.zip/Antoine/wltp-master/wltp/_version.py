"""Authoritative project's version-info"""
__version__ = "1.0.0.dev4"  ## Semantic-version: Update identifiers also in README.rst.
__updated__ = "2019-06-27 13:25:45"
