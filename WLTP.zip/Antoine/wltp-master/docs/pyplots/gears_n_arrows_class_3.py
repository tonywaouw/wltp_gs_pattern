#!/usr/bin/env python
#-*- coding: utf-8 -*-
#
# Copyright 2013-2019 European Commission (JRC);
# Licensed under the EUPL (the 'Licence');
# You may not use this work except in compliance with the Licence.
# You may obtain a copy of the Licence at: http://ec.europa.eu/idabc/eupl


if __name__ == '__main__':
    import gears_n_arrows as p
    from matplotlib import pyplot as plt

    p.plot(3)
    plt.show()