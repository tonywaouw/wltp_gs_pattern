.. include:: ../README.rst
    :end-before: _end-opening:

.. toctree::
    :numbered:

    intro
    usage
    contribute
    annex-2
    metrics
    faq
    code
    CHANGES
    indices

.. include:: ../README.rst
    :start-after: _begin-glossary:
