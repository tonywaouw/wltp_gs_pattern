=======
Indices
=======

.. include:: ../README.rst
    :start-after: _begin-glossary:

:ref:`Index <genindex>`
-----------------------

