from collections import OrderedDict as odic         ## It is handy to preserve keys-order.
from matplotlib import pyplot as plt

import os, io
import pickle
import tempfile
import numpy as np
import numpy.testing as npt
import pandas as pd

#from wltp
import wltp
from wltp import model
from wltp.experiment import Experiment
from goodvehicle import goodVehicle
from plotCycles import make_class_fig

def print_keys(dict, name):
    print("<> Value for dict ", name, "\n")
    for key, value in dict.items():
        print(key)

def simpleGoodVehicle():
    mdl = goodVehicle()
    
    exp = Experiment(mdl)
    mdl = exp._model
    
    #default model merged with goodVeh
    print_keys(mdl["vehicle"], "Vehicule")
    print_keys(mdl["params"], "Parameters")
          
    out = exp.run()
    
    print_keys(mdl["cycle_run"], "cycle_run")

    df = pd.DataFrame(mdl['cycle_run']);
    df.index.name = 't'



# AS info
def _compare_exp_results(tabular, savename, fname, run_comparison=True):
    
    tmpfname = os.path.join(tempfile.gettempdir(), "%s.pkl" % fname)
    if run_comparison:
        try:
            with io.open(tmpfname, "rb") as tmpfile:
                data_prev = pickle.load(tmpfile)
                print(tabular["cycle_run"]["gears"])

                #npt.assert_array_equal(tabular["cycle_run"]["gears"], data_prev["cycle_run"]["gears"])
                # Unreached code in case of assertion.
                cmp = tabular["cycle_run"]['gears'] != data_prev["cycle_run"]['gears']
                if (cmp.any()):
                    print("Plotting :")
                    print(data_prev["cycle_run"])
                    _plotResults(data_prev)
                    print('>> COMPARING(%s): %s'%(fname, cmp.nonzero()))
                else:
                    print("No plot")
                    print('>> COMPARING(%s): OK'%fname)

        except (FileNotFoundError, ValueError) as ex:  # @UnusedVariable
            print(
                  ">> COMPARING(%s): No old-tabular found, 1st time to be stored in: "
                  % fname,
                  tmpfname,
            )
            run_comparison = False
                
    #if not run_comparison:

    #save file
    savefname = os.path.join(tempfile.gettempdir(), "%s.pkl" % savename)
    print("Saved this file as ",savename, ".pkl in", tempfile.gettempdir())
    with io.open(savefname, "wb") as tmpfile:
        pickle.dump(tabular, tmpfile)


def _plotResults(model, title="Figure"):
    cycle = model["cycle_run"]
    gears = cycle["gears"]
    target = cycle["v_target"]
    realv = cycle["v_real"]
    clutch = cycle["clutch"]
    
    clutch = clutch.nonzero()[0]
    plt.vlines(clutch, 0, 40)
    plt.plot(target)
    plt.plot(gears * 12, "+")
    plt.plot(realv)
    plt.gcf().canvas.set_window_title(title)

def plotCyclesGraphs():
    wltc_data = model._get_wltc_data()
    for (class_name, class_data) in wltc_data['classes'].items():
        fig = make_class_fig(class_name, class_data)
        plt.show()
    
def testGoodVehicle(plot_results=False):
    
    model = goodVehicle()
    
    experiment = Experiment(model)
    model = experiment.run()
    
    print("DRIVEABILITY: \n%s" % experiment.driveability_report())
    cycle = model["cycle_run"]
    gears = cycle["gears"]
    print(
          "G1: %s, G2: %s"
          % (np.count_nonzero(gears == 1), np.count_nonzero(gears == 2))
          )
        
          
    if plot_results:
        print(model["cycle_run"])
        # print([_get_wltc_data()['classes']['class3b']['cycle_run'][k] for k in model['cycle_run']['driveability_issues'].keys()])
        _plotResults(model)

        np.set_printoptions(edgeitems=16)
        # print(driveability_issues)
        # print(v_max)
        # results['target'] = []; print(results)
        plt.show()

def testUnderPowered(plot_results=False):
    model = goodVehicle()
    model["vehicle"]["p_rated"] = 50
    
    experiment = Experiment(model)
    model = experiment.run()
    print("DRIVEABILITY: \n%s" % experiment.driveability_report())
    #_compare_exp_results(model, "unpower1", "unpower2",False)
    
    driver_weight = 70 #kg
    
    model = goodVehicle()
    veh = model["vehicle"]
    veh["test_mass"] = 1000
    veh["unladen_mass"] = veh["test_mass"] - driver_weight
    veh["p_rated"] = 80
    veh["v_max"] = 120
    veh["gear_ratios"] = [120.5, 95, 72, 52]
    
    experiment = Experiment(model)
    model = experiment.run()
    print("DRIVEABILITY: \n%s" % experiment.driveability_report())
    #_compare_exp_results(model, "unpower2", "unpower1",False)
    
    if plot_results:
        _plotResults(model)
        plt.show()


def fullExample(className, plot_results=False):

    model = goodVehicle() #exemple vehicule
    
    veh = model["vehicle"]
    #test insufficient power
    #veh["p_rated"] = 50

    #dont forget to add in cycles + model (!! also in enum !!)
    # >>> check for ClassNico

    ## From model._get_model_base() ::
    ## Form Heinz-db
    petrol = [ 0.1, 0.11100069, 0.12200138, 0.13300206, 0.14400275, 0.15500344, 0.16600413, 0.17700482, 0.1880055, 0.19900619, 0.21000688, 0.22100757, 0.23200826, 0.24300895, 0.25400963, 0.26501032, 0.27506528, 0.28512023, 0.29517519, 0.30523015, 0.3152851, 0.3231181, 0.3309511, 0.3387841, 0.3466171, 0.3544501, 0.3622831, 0.37011609, 0.37794909, 0.38578209, 0.39361509, 0.40268373, 0.41175238, 0.42082102, 0.42988967, 0.43895831, 0.44802696, 0.4570956, 0.46616424, 0.47523289, 0.48430153, 0.49385337, 0.5034052, 0.51295704, 0.52250887, 0.53206071, 0.54161255, 0.55116438, 0.56071622, 0.57026805, 0.57981989, 0.58873474, 0.59764959, 0.60656444, 0.61547929, 0.62439414, 0.633309, 0.64222385, 0.6511387, 0.66005355, 0.6689684, 0.67815415, 0.6873399, 0.69652565, 0.70571139, 0.71489714, 0.72408289, 0.73326864, 0.74245439, 0.75164013, 0.76082588, 0.77026954, 0.77971321, 0.78915687, 0.79860054, 0.8080442, 0.81748786, 0.82693153, 0.83637519, 0.84581885, 0.85526252, 0.86393898, 0.87261544, 0.8812919, 0.88996837, 0.89864483, 0.90732129, 0.91599775, 0.92467422, 0.93335068, 0.94202714, 0.94782443, 0.95362171, 0.959419, 0.96521628, 0.97101357, 0.97681086, 0.98260814, 0.98840543, 0.99420271, 1.0, 0.99556631, 0.99113261, 0.98669892, 0.98226523, 0.97783154, 0.97339784, 0.96896415, 0.96453046, 0.96009677, 0.95566307, 0.94509677, 0.93453046, 0.92396415, 0.91339784, 0.90283154, 0.89226523, 0.88169892, 0.87113261, 0.86056631, 0.85, ]
    
    ## Form Heinz-db
    diesel = [ 0.1, 0.11632768, 0.13265536, 0.14898304, 0.16531072, 0.1816384, 0.19796609, 0.21429377, 0.23062145, 0.24694913, 0.26327681, 0.27956221, 0.29584762, 0.31213302, 0.32841843, 0.34470383, 0.36098924, 0.37727464, 0.39356004, 0.40984545, 0.42613085, 0.44289144, 0.45965203, 0.47641262, 0.49317321, 0.5099338, 0.52669439, 0.54345498, 0.56021557, 0.57697616, 0.59373675, 0.60775731, 0.62177786, 0.63579841, 0.64981897, 0.66383952, 0.67786007, 0.69188063, 0.70590118, 0.71992173, 0.73394229, 0.74334518, 0.75274808, 0.76215098, 0.77155387, 0.78095677, 0.79035967, 0.79976256, 0.80916546, 0.81856836, 0.82797126, 0.83355082, 0.83913039, 0.84470996, 0.85028953, 0.8558691, 0.86144867, 0.86702823, 0.8726078, 0.87818737, 0.88376694, 0.88861739, 0.89346785, 0.8983183, 0.90316876, 0.90801921, 0.91286967, 0.91772013, 0.92257058, 0.92742104, 0.93227149, 0.93551314, 0.93875479, 0.94199644, 0.94523809, 0.94847974, 0.95172139, 0.95496304, 0.95820469, 0.96144634, 0.96468798, 0.96645067, 0.96821335, 0.96997604, 0.97173872, 0.97350141, 0.97526409, 0.97702678, 0.97878946, 0.98055215, 0.98231483, 0.98408335, 0.98585187, 0.98762038, 0.9893889, 0.99115742, 0.99292593, 0.99469445, 0.99646297, 0.99823148, 1.0, 0.98871106, 0.97742212, 0.96613319, 0.95484425, 0.94355531, 0.93226637, 0.92097743, 0.9096885, 0.89839956, 0.88711062, 0.88339956, 0.8796885, 0.87597743, 0.87226637, 0.86855531, 0.86484425, 0.86113319, 0.85742212, 0.85371106, 0.85, ]
    n_norm = np.arange(0.0, 1.21, 0.01)
    ##
    
    veh["wltc_class"] = className
    veh["full_load_curve"] = {"n_norm": n_norm, "p_norm": petrol}
    
    experiment = Experiment(model,skip_model_validation=False, validate_wltc_data=True)
    
    model = experiment.run()

    #Only output here if unerpowered for example
    print("DRIVEABILITY: \n%s" % experiment.driveability_report())
    #_compare_exp_results(model, "unpower2", "unpower1",False)
    
    if plot_results:
        _plotResults(model, "Figure for " + className)
        plt.show()

    return model

##Main

if __name__ == "__main__":
    print("Check version : \n >> ")
    print(wltp.__version__ )
    
    #simpleGoodVehicle()
    
    #testGoodVehicle(True)
    #testUnderPowered()

    
    plotCyclesGraphs()
    outModelList = [fullExample(className, True) for className in ["class1", "class2", "class3a", "class3b"]]


